<?php
    function getComments($connection){
        $sql="SELECT * from comments";
        $result=$connection->query($sql);
        while($row=$result->fetch_assoc()){
        echo "<div class='comment-box'>"
             .$row['uid']."<br>"
            . $row['date']."<br>"
            . $row['message']
            ."</div>";
        }
    }
    function setComment($connection){
        if(isset($_POST['commentSubmit'])){
            
            $uid=$_POST['uid'];
            $date=$_POST['date'];
            $message=$_POST['message'];

            $sql="INSERT INTO comments (uid,date,message) VALUES ('$uid','$date', '$message')";
            $result=$connection->query($sql);
        }
    }

    
?>