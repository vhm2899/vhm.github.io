<?php
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    include("comments.inc.php");
    include("db_connect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comments</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    
   <img src="cute-cat.jpeg" alt="Anh meo">
    <?php
      echo  "<form action='".setComment($connection)."' method='POST'>
            <input type='hidden' name='uid' value='Anonymous'>
            <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
            <textarea name='message' id='mes'></textarea><br>
            <button type='submit' name='commentSubmit'>Comment</button>
            </form>";

            getComments($connection);
    ?>
</body>
</html>